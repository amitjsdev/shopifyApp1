<?php
ob_start();

require 'vendor/autoload.php';

use Carbon\Carbon;

use GuzzleHttp\Client; 
$dotenv = new Dotenv\Dotenv(__DIR__);

$dotenv->load(); 
$db = new Mysqli(getenv('MYSQL_HOST'), getenv('MYSQL_USER'), getenv('MYSQL_PASS'), getenv('MYSQL_DB'));  
$api_key = getenv('SHOPIFY_APIKEY');

$secret_key = getenv('SHOPIFY_SECRET'); 
$query = $_GET; 
/* echo "<pre>";
print_r($query); */
if (!isset($query['code'], $query['hmac'], $query['shop'], $query['timestamp'])) {

	exit;

} 
 $hmac = $query['hmac'];

unset($query['hmac']); 
$params = [];

foreach ($query as $key => $val) {

	$params[] = "$key=$val";

}  
asort($params);

$params = implode('&', $params);

$calculated_hmac = hash_hmac('sha256', $params, $secret_key); 
$store = $query['shop'];
//echo $hmac."cal ".$calculated_hmac;

if($hmac === $calculated_hmac){

    /* echo "ewreretrdtt";
	echo $hmac."cal ".$calculated_hmac;
	die; */

	$client = new Client(); 
	$response = $client->request(

		'POST', 

		"https://{$store}/admin/oauth/access_token",

		[

			'form_params' => [

				'client_id' => $api_key,

				'client_secret' => $secret_key,

				'code' => $query['code']

			]

		]

	); 
	$data = json_decode($response->getBody()->getContents(), true);
	//print_r($data);
//	echo "vvvvvvvvvvvvvvvvvvvvvv";
    $access_token = $data['access_token'];
   
   //echo "SELECT nonce FROM installs WHERE store = '$store'";
	$select_nonce = $db->query("SELECT nonce FROM installs WHERE store = '$store'");
	if($select_nonce->num_rows > 0) {
	    $get_res = $select_nonce->fetch_object();
        $nonce_val = $get_res->nonce;
	}

	  
  $nonce = $nonce_val; 
   //die;
   
	if ($select = $db->prepare("SELECT id FROM installs WHERE store = ? AND nonce = ?")) {

		$select->bind_param('ss', $store, $nonce);

		$select->execute();

		$select->bind_result($id);

		$select->fetch();

		$select->close(); 
		if ($id > 0) {
           // echo "UPDATE installs SET access_token = '$access_token' WHERE id = '$id'";
			$db->query("UPDATE installs SET access_token = '$access_token' WHERE id = '$id'");
			//die;

		}

	}
	
	    $response_webhook  = $client->request(
		'GET', 
		"https://{$store}/admin/webhooks.json",
		[   
			'query' => [
				'fields' => 'id,topic',
				'access_token' => $access_token
			]
		]
	);

	$get_res_webhook  = json_decode($response_webhook ->getBody()->getContents(), true);
	
	$res_title_webhook = array();
 	foreach($get_res_webhook['webhooks'] as $r){
		$res_title_webhook[] = $r['topic'];
 	}
    
    if (in_array("app/uninstalled", $res_title_webhook)){}
	else{
		$arguments_webhook = [
	   'webhook' => [
		'topic' => 'app/uninstalled',
			   'address' => 'https://fortvision.com/shopify/uninstalled.php' 
			   ]
		];
		$response_script_webhook = $client->request('POST', 'https://'.$store.'/admin/webhooks.json', [
		   'json'    => $arguments_webhook,
		   'headers' => ['X-Shopify-Access-Token' => $access_token]
		]);
	}
	//code end webhooks
	
	    echo "<script>window.location = 'https://".$store."/admin/apps/fortvision?shop=".$store."'</script>";
	
	}
